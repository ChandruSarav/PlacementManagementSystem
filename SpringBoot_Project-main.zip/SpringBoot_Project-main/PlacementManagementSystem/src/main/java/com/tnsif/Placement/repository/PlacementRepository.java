package com.tnsif.Placement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tnsif.Placement.entity.Placement;

public interface PlacementRepository extends JpaRepository<Placement, Long> {
	

}
